package server;

import java.sql.*;

public class DatabaseManager {
    private Connection conn;

    public DatabaseManager() {
        try {
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:drinkstore.db");
            initializeTables();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void initializeTables() throws SQLException {
        String orders = "CREATE TABLE IF NOT EXISTS orders (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "customer TEXT, item TEXT, quantity INTEGER, branch TEXT, timestamp TEXT, price REAL)";

        String stock = "CREATE TABLE IF NOT EXISTS stock (" +
                "branch TEXT, item TEXT, quantity INTEGER, PRIMARY KEY(branch, item))";

        try (Statement stmt = conn.createStatement()) {
            stmt.execute(orders);
            stmt.execute(stock);
        }
    }

    public void insertOrder(String customer, String item, int quantity, String branch, String timestamp) {
        try {
            double price = 70; // fixed price
            String sql = "INSERT INTO orders (customer, item, quantity, branch, timestamp, price) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, customer);
            stmt.setString(2, item);
            stmt.setInt(3, quantity);
            stmt.setString(4, branch);
            stmt.setString(5, timestamp);
            stmt.setDouble(6, price);
            stmt.executeUpdate();

            updateStock(item, branch, -quantity);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateStock(String item, String branch, int deltaQty) throws SQLException {
        String select = "SELECT quantity FROM stock WHERE branch = ? AND item = ?";
        PreparedStatement check = conn.prepareStatement(select);
        check.setString(1, branch);
        check.setString(2, item);
        ResultSet rs = check.executeQuery();

        if (rs.next()) {
            int newQty = rs.getInt("quantity") + deltaQty;
            PreparedStatement update = conn.prepareStatement("UPDATE stock SET quantity = ? WHERE branch = ? AND item = ?");
            update.setInt(1, newQty);
            update.setString(2, branch);
            update.setString(3, item);
            update.executeUpdate();
        } else {
            PreparedStatement insert = conn.prepareStatement("INSERT INTO stock (branch, item, quantity) VALUES (?, ?, ?)");
            insert.setString(1, branch);
            insert.setString(2, item);
            insert.setInt(3, Math.max(deltaQty, 0));
            insert.executeUpdate();
        }
    }

    public void addStockForBranch(String branch, String item, int qty) {
        try {
            updateStock(item, branch, qty);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getStockReportText() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Current Stock Levels (Per Branch) ===\n");
        try {
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM stock ORDER BY branch, item");
            while (rs.next()) {
                String branch = rs.getString("branch");
                String item = rs.getString("item");
                int qty = rs.getInt("quantity");
                sb.append(branch).append(" - ").append(item).append(": ").append(qty).append(" units\n");
            }
        } catch (SQLException e) {
            sb.append("Error fetching stock: ").append(e.getMessage());
        }
        return sb.toString();
    }

    public String getCustomerListText() {
        StringBuilder sb = new StringBuilder();
        try {
            ResultSet rs = conn.createStatement().executeQuery("SELECT DISTINCT customer FROM orders");
            sb.append("=== Customers Who Made Orders ===\n");
            while (rs.next()) {
                sb.append("- ").append(rs.getString("customer")).append("\n");
            }
        } catch (SQLException e) {
            sb.append("Error fetching customer list: ").append(e.getMessage());
        }
        return sb.toString();
    }

    public String getSalesByBranchText() {
        StringBuilder sb = new StringBuilder();
        try {
            ResultSet rs = conn.createStatement().executeQuery(
                "SELECT branch, SUM(quantity * price) as total_sales FROM orders GROUP BY branch");
            sb.append("=== Sales by Branch ===\n");
            while (rs.next()) {
                sb.append(rs.getString("branch")).append(": KES ")
                  .append(rs.getDouble("total_sales")).append("\n");
            }
        } catch (SQLException e) {
            sb.append("Error fetching sales by branch: ").append(e.getMessage());
        }
        return sb.toString();
    }

    public String getTotalSalesText() {
        StringBuilder sb = new StringBuilder();
        try {
            ResultSet rs = conn.createStatement().executeQuery("SELECT SUM(quantity * price) AS total FROM orders");
            if (rs.next()) {
                sb.append("=== Total Sales Across All Branches ===\n");
                sb.append("Total: KES ").append(rs.getDouble("total")).append("\n");
            }
        } catch (SQLException e) {
            sb.append("Error fetching total sales: ").append(e.getMessage());
        }
        return sb.toString();
    }
    // Add stock to a specific branch (fixed price = 70)
public void addBranchStock(String item, String branch, int qty) {
    try {
        String sql = "INSERT INTO stock (item, branch, quantity, price) VALUES (?, ?, ?, ?)" +
                     "ON CONFLICT(item, branch) DO UPDATE SET quantity = quantity + excluded.quantity";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, item);
        stmt.setString(2, branch);
        stmt.setInt(3, qty);
        stmt.setDouble(4, 70); // Fixed price
        stmt.executeUpdate();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}
