package server;

import javax.xml.crypto.Data;

public class ReportRunner {
    public static void main(String[] args) {
        DatabaseManager db = new DatabaseManager();
        db.printCustomerList();
        db.printSalesByBranch();
        db.printTotalSales();
        db.printStockReport();
        System.out.println("Report generation completed successfully.");
    }
}
