package server;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.time.format.DateTimeFormatter;

import models.Order;

public class ServerApp {

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(5000)) {
            System.out.println("[SERVER] Server started on port 5000");

            DatabaseManager db = new DatabaseManager();
            db.insertInitialStockIfMissing(); // Ensure stock table is prefilled

            while (true) {
                try {
                    Socket socket = serverSocket.accept();
                    System.out.println("[SERVER] Connection received...");

                    ObjectInputStream input = new ObjectInputStream(socket.getInputStream());
                    ObjectOutputStream output = new ObjectOutputStream(socket.getOutputStream());
                    Order order = (Order) input.readObject();
                    

                    System.out.println("[SERVER] Order received: " + order);

                    
                    // String timestamp = order.getOrderTime()
                    //     .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                    // db.insertOrder(order.getCustomer(), order.getItem(), order.getQuantity(),
                    //                order.getBranchName(), timestamp);

                    // Update stock
                    int currentStock = db.getStock(order.getItem());
                    if (currentStock < order.getQuantity()){
                        output.writeObject("Error: Not enough stock for " + order.getItem() + "(Available:"+ currentStock + ")");

                    }else{
                        //Proceed with order
                        String timestamp = order.getOrderTime()
                            .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
                            db.insertOrder(order.getCustomer(),order.getItem(),order.getQuantity(),order.getBranchName(),timestamp);    
                    }
                int newStock = currentStock - order.getQuantity();
                    db.updateStock(order.getItem(), newStock);

                    if (newStock <= 5) {
                        System.out.println("[ALERT] Low stock for " + order.getItem() + ": "
                                           + newStock + " units left.");
                    }
                    output.writeObject("Order placed successfully");
                    input.close();
                    socket.close();

                } catch (Exception ex) {
                    ex.printStackTrace(); // Handle single client error, keep server alive
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

