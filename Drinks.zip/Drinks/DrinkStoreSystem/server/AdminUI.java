package server;

import javax.swing.*;
import java.awt.*;

public class AdminUI {

    public static void main(String[] args) {
        // === Window Setup ===
        JFrame frame = new JFrame("Admin Dashboard");
        frame.setSize(700, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // === Output Area ===
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // === Button Panel ===
        JPanel buttonPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        JButton customersBtn = new JButton("View Customers");
        JButton salesBranchBtn = new JButton("View Sales by Branch");
        JButton totalSalesBtn = new JButton("View Total Sales");
        JButton stockReportBtn = new JButton("View Current Stock");

        buttonPanel.add(customersBtn);
        buttonPanel.add(salesBranchBtn);
        buttonPanel.add(totalSalesBtn);
        buttonPanel.add(stockReportBtn);

        // === Add Stock Panel ===
        JPanel stockPanel = new JPanel(new GridLayout(1, 4, 10, 10));
        JComboBox<String> itemBox = new JComboBox<>(new String[]{"Coke", "Fanta", "Sprite"});
        JTextField qtyField = new JTextField();
        JComboBox<String> branchBox = new JComboBox<>(new String[]{"Nakuru", "Mombasa", "Nairobi", "Kisumu"});
        JButton addStockBtn = new JButton("Add Stock");

        stockPanel.add(itemBox);
        stockPanel.add(qtyField);
        stockPanel.add(branchBox);
        stockPanel.add(addStockBtn);

        // === Add Panels to Frame ===
        frame.add(buttonPanel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.add(stockPanel, BorderLayout.SOUTH);

        frame.setVisible(true);

        // === DB Connection ===
        DatabaseManager db = new DatabaseManager();

        // === Button Actions ===
        customersBtn.addActionListener(e -> {
            outputArea.setText(db.getCustomerListText());
        });

        salesBranchBtn.addActionListener(e -> {
            outputArea.setText(db.getSalesByBranchText());
        });

        totalSalesBtn.addActionListener(e -> {
            outputArea.setText(db.getTotalSalesText());
        });

        stockReportBtn.addActionListener(e -> {
            outputArea.setText(db.getStockReportText());
        });

        addStockBtn.addActionListener(e -> {
            String item = (String) itemBox.getSelectedItem();
            String branch = (String) branchBox.getSelectedItem();
            try {
                int qty = Integer.parseInt(qtyField.getText().trim());
                db.addBranchStock(item, branch, qty); // fixed price handled inside
                outputArea.setText(" Added " + qty + " " + item + " to " + branch + " branch.\n\n" +
                                   db.getStockReportText());
                qtyField.setText("");
            } catch (NumberFormatException ex) {
                outputArea.setText(" Quantity must be a valid number.");
            }
        });
    }
}
